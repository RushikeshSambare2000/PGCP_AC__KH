//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdio.h>

void func(int val){
	printf("inside int func!");
}

void func(int* val){
	printf("inside int* func!");
}


int main() {

	func(nullptr);		// NULL: is a macro which stores int value 0 in it.

	int* pt = nullptr; // type: nullprt_t

	int* ptr = NULL;

	int num = 10;

	int &ref = num;		// reference variable

	int* ptrNum = &num;	// pointer to num




	return 0;
}
