//============================================================================
// Name        : 3.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

struct Student{
    int rollNo;
    char name[50];
    float marks;
};	// student ends here

void acceptData(struct Student *s){
	printf("Enter Roll NO:");
	scanf("%d", &s->rollNo);
	printf("Enter Name:");
	scanf("%s", s->name);
	printf("Enter Marks:");
	scanf("%f", &s->marks);		//s->marks :(*s).marks
}

void displayData(struct Student s){
	printf("\n Student: RollNO: %d, Name: %s, Marks: %f", s.rollNo, s.name, s.marks);
}


int main(){
    struct Student s1;

//    acceptData(rollno, name, marks);

    acceptData(&s1);
    displayData(s1);

    return 0;
}
