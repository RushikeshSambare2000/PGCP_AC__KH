#include <stdio.h>

int main(){

	int val = 10;

	const int* const ptr = &val;

//	const * const int ptr;	//invalid syntax

//	*ptr = 20;	// invalid- error: assignment of read-only location '*(const int*)ptr'
	int num = 20;

//	ptr = &num;	// invalid- error: assignment of read-only variable 'ptr'

	printf("val: %d", val);

	return 0;
}





int main2(){

	int val = 10;

	int* const ptr = &val;
//	int* ptr1 const;  invalid syntax

	*ptr = 20;	// valid

	int num = 20;

//	ptr = &num;	// invalid- error: assignment of read-only variable 'ptr'

	printf("val: %d", val);

	return 0;

}





int main1(){

	int val = 10;

	//constant pointer
	const int *ptr = &val;
//	int const *ptr

	int num = 20;

	ptr = &num;	// valid

//	*ptr = 20;	// invalid- error: assignment of read-only location '*ptr'

	printf("ptr: %p", ptr);

	return 0;
}
