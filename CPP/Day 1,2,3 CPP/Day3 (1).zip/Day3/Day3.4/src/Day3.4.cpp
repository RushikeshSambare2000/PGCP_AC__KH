//============================================================================
// Name        : 4.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

struct Student{
private:			//public, private and protected
	int rollNo;
	float marks;

public:
	void acceptData(){
		printf("Enter Roll NO:");
		scanf("%d", &rollNo);
		printf("Enter Marks:");
		scanf("%f", &marks);
	}

	void displayData(){
		printf("\n Student: RollNO: %d, Marks: %f", rollNo, marks);
	}
};


int main() {

	Student s1;

	s1.acceptData();
	s1.displayData();

	int subject_marks = s1.marks;

//	s1.rollNo = 202;
//
	printf("Roll No: %d", s1.rollNo);
	printf("Marks: %f", s1.marks);

	return 0;
}
