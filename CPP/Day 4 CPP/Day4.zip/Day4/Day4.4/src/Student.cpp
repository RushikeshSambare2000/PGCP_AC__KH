/*
 * Student.cpp
 *
 *  Created on: 27-Feb-2026
 *      Author: Shilbhushan
 */
#include "Student.h"
#include <iostream>

using namespace std;

void Student::acceptData(){			// :: - Scope resolution
	cout << "Enter PRN: " << endl;
	cin >> rollNo;
	cout << "Enter Marks: " << endl;
	cin >> marks;
}

void Student::displayData(){
	cout << "Student: " << rollNo << " " << marks;
}


