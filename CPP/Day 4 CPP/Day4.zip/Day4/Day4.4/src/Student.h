/*
 * Student.h
 *
 *  Created on: 27-Feb-2026
 *      Author: Shilbhushan
 */

// header guards
#ifndef SRC_STUDENT_H_	//macro
#define SRC_STUDENT_H_

// modern syntax for header guard
#pragma once		// not standard way

class Student{
	int rollNo;
	float marks;
public:
	void acceptData();
	void displayData();
};

#endif /* SRC_STUDENT_H_ */
