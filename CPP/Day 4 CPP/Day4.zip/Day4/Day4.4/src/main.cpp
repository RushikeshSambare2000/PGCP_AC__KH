#include "iostream"	// std header files
#include <stdio.h>	//c style
#include <cstdio>	// c++ way
#include <cstring>	// c++ way
#include <Student.h>

//<> - predefined/system header
//"" - user-defined header

using namespace std;

int main(){

	Student s1;

	s1.acceptData();
	s1.displayData();

	return 0;
}
