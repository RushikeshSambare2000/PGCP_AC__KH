
//============================================================================
// Name        : main.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student{
	int rollNo;
	float marks;

public:
	void setRollNo(int num){
		if(num > 0 && num < 100)
			rollNo = num;
	}

	int getRollNo() const{
		return rollNo;
	}

	void setMarks(float num){
		if(num > 0 && num < 100)
			marks = num;
	}

	float getMarks() const{
		return marks;
	}
};



class Empty{

};

int main(){
	cout << "Size of Empty class: " << sizeof(Empty) << endl;
	cout << "Size of Student class: " << sizeof(Student) << endl;

}







class A{
	int num;
	char c;
};

int main2(){

	A obj;	//object creation

	cout << "Size of A:" << sizeof(obj) << endl;

//	class A{
//		int num;
//		char c;
//	};

//	int 		|  c | padding
//	1 2 3 4 |  5 | 6 7 8


//	class A{
//		char c;
//		int num;
//	};
//
//	  c | padding | int 		|
//	  1 | 2 3 4   |  5 6 7 8 |

	return 0;
}


int main1(){

	Student s;	// Object creation

	Student s1;

	s.setRollNo(10);

	s.setMarks(50.7);

	s1.setRollNo(30);

	s1.setMarks(87.7);

	cout << "Student : "<< s.getRollNo() << " " << s.getMarks() << endl;
	cout << "Student : "<< s1.getRollNo() << " " << s1.getMarks() << endl;

	cout << "Size of Student: " << sizeof(s) << endl;

	return 0;
}


