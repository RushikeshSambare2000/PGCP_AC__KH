//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student{
	int rollNo;

public:
	void setRollNo(int num){
		if(num > 0 && num < 100)
			rollNo = num;
	}

	int getRollNo() const{
		return rollNo;
	}
};

int main(){

	int num;		// variable declaration
	int num1;
	Student s;	// Object creation

	Student s1;

	s.setRollNo(10);

	s.setRollNo(-10);

	cout << s.getRollNo() << endl;

	return 0;
}


int main1() {

//	Employee e;	// struct

//	Student s;	// class

//	e.empId;

//	s.rollNo;	//error: 'int Student::rollNo' is private within this context

	return 0;
}
