//============================================================================
// Name        : 5.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

using std::cout;

int x = 10;		// global variable

namespace A{
	class Student{
	public:
		int rollNo;
		int getRollNo(){
			return rollNo;
		}
	};
	int x = 20;
}

namespace A{
	namespace B{

	}
}

//c++ 11/17
namespace A::B{

}

int main() {

	using A::x;

	cout << ::x << std::endl;
	cout << x << std::endl;
	return 0;
}
