//============================================================================
// Name        : 1.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

typedef struct Student{
	int rollNo;
} Stud;				// alias for Student

typedef struct StudentAttendanceManager{
	int attendanceCount;
} SAM;		// alias for Student

int main() {

	typedef int shil;	// alias for int

	SAM sam;

	shil num = 10;

	int num1 = 20;

	struct Student s;

	Stud s;

	return 0;
}
