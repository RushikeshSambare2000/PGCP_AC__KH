//============================================================================
// Name        : 6.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "COUT" << endl; // prints !!!Hello World!!!	// buffered
	cerr << "CERR" ; // prints !!!Hello World!!!	// unbuffered
	clog << "CLOG" ; // prints !!!Hello World!!!	// buffered

	return 0;
}
