/*
 * main.cpp
 *
 *  Created on: 28-Feb-2026
 *      Author: Shilbhushan
 */

#include <iostream>

using namespace std;

class Student{
	int rollNo;
	float marks;

public:

	//default constructor
	Student(){
		rollNo = 0;
		marks = 0;
	}


	Student(int roll){
		rollNo = roll;
	}

	Student(float m){
		marks = m;
	}

	// parameterized constructor
	Student(int rn, float m){
		rollNo = rn;
		marks = m;
	}

	float getMarks() const {
		return marks;
	}

	void setMarks(float m) {
		marks = m;
	}

	int getRollNo() const {
		return rollNo;
	}

	void setRollNo(int rn) {
		rollNo = rn;
	}
};

int main(){

	Student s;			//default cons
	Student s1(101, 50);// Parameterized cons
	Student s2(55.5);		// single parameter cons


	s1.setRollNo(121);
	s1.setMarks(60);

	cout << "Student RollNo: "<< s.getRollNo() << " Student Marks: "<< s.getMarks() << endl;
	cout << "Student RollNo: "<< s1.getRollNo() << " Student Marks: "<< s1.getMarks() << endl;
	cout << "Student RollNo: "<< s2.getRollNo() << " Student Marks: "<< s2.getMarks() << endl;

	return 0;
}


