//============================================================================
// Name        : 2.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student{
	int rollNo;
	float marks;

public:
	// right to left
	Student(int rn = 0, float m = 0){
		rollNo = rn;
		marks = m;
	}

	float getMarks() const {
		return marks;
	}

	void setMarks(float marks) {
		this->marks = marks;
	}

	int getRollNo() const {
		return rollNo;
	}

	void setRollNo(int rollNo) {
		this->rollNo = rollNo;
	}
};


int main() {
//	Student s;
	Student s1(101, 50);

//	cout << s.rollNo << " " << s.marks<<endl;
cout << s1.rollNo << " " << s1.marks<<endl;
	return 0;
}
