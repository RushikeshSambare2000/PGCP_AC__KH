/*
 * main.cpp
 *
 *  Created on: 28-Feb-2026
 *      Author: Shilbhushan
 */
#include <iostream>
using namespace std;

class Student{
	const int rollNo;
	float marks;

public:

	//para cons
	Student(int rollNo, float marks){
		cout << "Constrcutor called!"
	}

	// const Student* this const
	float getMarks() const {
		return marks;
	}

	void setMarks(float marks) {
		this->marks = marks;
	}

	int getRollNo() const {
		return rollNo;
	}
};


int main() {

	Student s(101, 50);
	Student s1(101, 54);

	cout << s.getRollNo() << " | " << s.getMarks() << endl;
	cout << s1.getRollNo() << " | " << s1.getMarks() << endl;

	return 0;
}



