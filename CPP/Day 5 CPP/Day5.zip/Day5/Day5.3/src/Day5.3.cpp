//============================================================================
// Name        : 3.cpp
// Author      : shil
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Student{
	int rollNo;
	float marks;

public:

	// this pointer Student const *this
	// in case of const object: const Student const *this
	Student(int rollNo = 0, float Marks = 0){
		this->rollNo = rollNo;
		this->marks = Marks;
	}

	float getMarks() const {
		return marks;
	}

	void setMarks(float marks) {
		this->marks = marks;
	}

	int getRollNo() const {
		return rollNo;
	}

	void setRollNo(int rollNo) {
		this->rollNo = rollNo;
	}
};


int main() {

	Student s;	// this -> object address
	const Student s1(101, 50);

//	const Student s2(100);

	//error: passing 'const Student' as 'this' argument discards qualifiers
//	s1.setRollNo(111);
//	s1.setMarks(20);

//	setRollNo(&s, 101);
//
//	void setRollNo(Student *this, int rollNo){
//		this->rollNo = rollNo;
//	}(

	s.getRollNo(); // s1 - x, s ==

	cout << "Roll NO: " << s.getRollNo() << " Marks: " << s.getMarks() << endl;
	cout << "Roll NO: " << s1.getRollNo() << " Marks: " << s1.getMarks() << endl;

	return 0;
}
